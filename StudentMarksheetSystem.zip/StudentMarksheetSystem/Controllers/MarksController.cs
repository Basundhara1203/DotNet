﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using StudentMarksheetSystem.Models;

namespace StudentMarksheetSystem.Controllers
{
    public class MarksController : Controller
    {
        // GET: Marks
        public ActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Index(HttpPostedFileBase excelfile)
        {
            if(excelfile== null || excelfile.ContentLength==0)
            {
                ViewBag.Error = "Please select an excel file";
                return View("Index");
            }
            else
            {
                if (excelfile.FileName.EndsWith("xls") || excelfile.FileName.EndsWith("xlsx"))
                {
                    string path = Server.MapPath("~/Content/" + excelfile.FileName);

                    /*if (System.IO.File.Exists(path))
                        System.IO.File.Delete(path);*/
                        
                    excelfile.SaveAs(path);
                    Excel.Application application = new Excel.Application();
                    Excel.Workbook workbook = application.Workbooks.Open(path);
                    Excel.Worksheet worksheet = workbook.ActiveSheet;
                    Excel.Range range = worksheet.UsedRange;
                    MarkSheetContext ms = new MarkSheetContext();
                    for (int row = 2; row <= range.Rows.Count; row++)
                    {
                        MarkSheet m = new MarkSheet();
                        m.Student_Roll_Number = int.Parse(((Excel.Range)range.Cells[row, 1]).Text);
                        m.FirstName = ((Excel.Range)range.Cells[row, 2]).Text;
                        m.LastName = ((Excel.Range)range.Cells[row, 3]).Text;
                        m.Physics = int.Parse(((Excel.Range)range.Cells[row, 4]).Text);
                        m.Chemistry = int.Parse(((Excel.Range)range.Cells[row, 5]).Text);
                        m.Maths = int.Parse(((Excel.Range)range.Cells[row, 6]).Text);
                        m.English = int.Parse(((Excel.Range)range.Cells[row, 7]).Text);
                        m.Computer = int.Parse(((Excel.Range)range.Cells[row, 8]).Text);
                        m.Total = int.Parse(((Excel.Range)range.Cells[row, 9]).Text);
                        Console.WriteLine(m.Student_Roll_Number + m.FirstName + m.LastName);
                        ms.MarkSheets.Add(m);
                        ms.SaveChanges();




                    }
                    return RedirectToAction("Show");
                }
                else
                { 
                        ViewBag.Error = "File Type is Incorrect";
                    return View("Index");
                }

               
            }
            
        }


        public ActionResult Show()
        {
            using (MarkSheetContext ds = new MarkSheetContext())
            {
                List<MarkSheet> MarkSheets = ds.MarkSheets.Where(x => x.Total > 300).ToList();
                 return View(MarkSheets);
            }
        }

        public ActionResult ShowMarks()
        {
            using (MarkSheetContext ds = new MarkSheetContext())
            {
                List<MarkSheet> MarkSheets = ds.MarkSheets.Where(x => x.Total > 300).ToList();





                return PartialView(MarkSheets);
            }

        }



    }
}