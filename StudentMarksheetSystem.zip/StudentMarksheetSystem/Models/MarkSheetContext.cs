﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace StudentMarksheetSystem.Models
{
    public class MarkSheetContext : DbContext
    {
       
    
        public MarkSheetContext() : base("MarkSheetContext") { }

        public DbSet<MarkSheet> MarkSheets { get; set; }
       
    }
}