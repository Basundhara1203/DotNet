﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace StudentMarksheetSystem.Models
{
    public class MarkSheet
    {   [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Student_Roll_Number { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Physics { get; set; }
        public int Chemistry { get; set; }
        public int Maths { get; set; }
        public int English { get; set; }
        public int Computer{ get; set; }

        public int Total { get; set; }

    }
}