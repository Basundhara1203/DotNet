﻿namespace StudentMarksheetSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class b : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.MarkSheets", "Maths", c => c.Int(nullable: false));
            AddColumn("dbo.MarkSheets", "English", c => c.Int(nullable: false));
            DropColumn("dbo.MarkSheets", "Mathematics");
        }
        
        public override void Down()
        {
            AddColumn("dbo.MarkSheets", "Mathematics", c => c.Int(nullable: false));
            DropColumn("dbo.MarkSheets", "English");
            DropColumn("dbo.MarkSheets", "Maths");
        }
    }
}
