﻿namespace StudentMarksheetSystem.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class a : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.MarkSheets",
                c => new
                    {
                        Student_Roll_Number = c.Int(nullable: false),
                        FirstName = c.String(),
                        LastName = c.String(),
                        Physics = c.Int(nullable: false),
                        Chemistry = c.Int(nullable: false),
                        Mathematics = c.Int(nullable: false),
                        Computer = c.Int(nullable: false),
                        Total = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Student_Roll_Number);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.MarkSheets");
        }
    }
}
